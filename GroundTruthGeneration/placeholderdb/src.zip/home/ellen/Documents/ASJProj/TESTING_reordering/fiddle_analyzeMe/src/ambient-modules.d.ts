declare module 'fix-path';
declare module 'namor';
