export function shouldQuit() {
  return require('electron-squirrel-startup');
}
