export const execMock = jest.fn();
