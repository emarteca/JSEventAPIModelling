import { html } from '../../src/content/html';

describe('content/html', () => {
  it('has content', () => {
    expect(html.length).toBeGreaterThan(0);
  });
});
