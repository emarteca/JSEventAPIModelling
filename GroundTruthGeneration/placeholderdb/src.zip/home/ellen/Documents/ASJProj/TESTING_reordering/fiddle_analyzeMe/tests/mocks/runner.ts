export class RunnerMock {
  public run = jest.fn();
  public stop = jest.fn();
}
