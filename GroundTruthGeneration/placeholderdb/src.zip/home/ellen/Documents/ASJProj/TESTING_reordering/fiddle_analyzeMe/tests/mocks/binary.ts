export class MockBinaryManager {
  public remove = jest.fn();
  public setup = jest.fn();
  public getDownloadedVersions = jest.fn();
  public getDownloadingVersions = jest.fn();
}
