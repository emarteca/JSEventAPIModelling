export class RemoteLoader {
  public loadFiddleFromGist = jest.fn();
  public loadFiddleFromElectronExample = jest.fn();
  public fetchGistAndLoad = jest.fn();
}
